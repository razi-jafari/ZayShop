<template>
  <div class="nested-menue" >
   <div >
       تماس با ما
  </div>
    
   
  </div>
</template>

<script>

export default {
  name: 'Contact',
  
}
</script>

<style>
    @import '../assets/css/NestedMenu.css';
</style>
