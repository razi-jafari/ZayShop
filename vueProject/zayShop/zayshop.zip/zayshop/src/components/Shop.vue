<template>
  <div class="nested-menue" >
   <div >
       فروشگاه
  </div>
    
   
  </div>
</template>

<script>

export default {
  name: 'Shop',
  
}
</script>

<style>
    @import '../assets/css/NestedMenu.css';
</style>
