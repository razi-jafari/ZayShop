<template>
  <div class="nested-menue" >
   <div >
       خانه
  </div>
    
   
  </div>
</template>

<script>

export default {
  name: 'Home',
  
}
</script>

<style>
    @import '../assets/css/NestedMenu.css';
</style>
