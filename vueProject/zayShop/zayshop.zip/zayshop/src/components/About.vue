<template>
  <div class="nested-menue" >
   <h1>درباره ما</h1>
    
   
  </div>
</template>

<script>

export default {
  name: 'About',
  
}
</script>

<style>
    @import '../assets/css/NestedMenu.css';
</style>
